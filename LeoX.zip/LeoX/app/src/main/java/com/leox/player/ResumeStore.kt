package com.leox.player

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.leoxStore by preferencesDataStore(name = "leox_resume")

object ResumeStore {
    private fun key(uri: String) = longPreferencesKey("pos_" + uri.hashCode())

    suspend fun load(context: Context, uri: String): Long =
        context.leoxStore.data.first()[key(uri)] ?: 0L

    suspend fun save(context: Context, uri: String, positionMs: Long) {
        context.leoxStore.edit { it[key(uri)] = positionMs }
    }
}
