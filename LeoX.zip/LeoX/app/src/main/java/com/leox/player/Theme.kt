package com.leox.player

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object LeoXColors {
    val Background = Color(0xFF05070A)
    val Surface = Color(0xFF0B1016)
    val Panel = Color(0xFF111923)
    val Accent = Color(0xFF35D8FF)
    val Text = Color(0xFFF5F8FA)
    val Muted = Color(0xFF91A0AA)
}

private val Scheme = darkColorScheme(
    primary = LeoXColors.Accent,
    onPrimary = LeoXColors.Background,
    background = LeoXColors.Background,
    onBackground = LeoXColors.Text,
    surface = LeoXColors.Surface,
    onSurface = LeoXColors.Text,
    surfaceVariant = LeoXColors.Panel,
    onSurfaceVariant = LeoXColors.Muted
)

@Composable
fun LeoXTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
