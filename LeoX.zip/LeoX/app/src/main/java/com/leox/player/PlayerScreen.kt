package com.leox.player

import android.net.Uri
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

@Composable
fun PlayerScreen(uri: Uri) {
    val context = LocalContext.current
    val uriString = uri.toString()
    val player = remember { ExoPlayer.Builder(context).build() }

    LaunchedEffect(uriString) {
        val resume = ResumeStore.load(context, uriString)
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        if (resume > 0) player.seekTo(resume)
        player.playWhenReady = true
        // Periodic position save so progress survives process death.
        while (true) {
            delay(5000)
            if (player.playbackState != androidx.media3.common.Player.STATE_IDLE) {
                ResumeStore.save(context, uriString, player.currentPosition)
            }
        }
    }

    DisposableEffect(player) {
        onDispose {
            val pos = player.currentPosition
            runBlocking { ResumeStore.save(context, uriString, pos) }
            player.release()
        }
    }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                setBackgroundColor(android.graphics.Color.BLACK)
            }
        }
    )
}
