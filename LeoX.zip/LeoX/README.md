# LeoX (Phase 1)
Kotlin + Compose + Media3 player. Targets Tecno Spark 6 Go (armeabi-v7a + arm64-v8a, minSdk 24).

## Build the APK
**GitHub:** push this folder to a new repo -> Actions tab -> "Build LeoX APK" -> download artifact `LeoX-apk` (contains LeoX.apk).
**Android Studio:** open folder -> Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk.
